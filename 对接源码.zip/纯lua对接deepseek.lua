--[[
作者: 白夜
]]

local function bj(sj)
    if type(sj) == "table" then
        local xm = {}
        if #sj > 0 then
            for _, zhi in ipairs(sj) do
                table.insert(xm, bj(zhi))
            end
            return "[" .. table.concat(xm, ",") .. "]"
        else
            for k, v in pairs(sj) do
                table.insert(xm, '"' .. k .. '":' .. bj(v))
            end
            return "{" .. table.concat(xm, ",") .. "}"
        end
    elseif type(sj) == "string" then
        return '"' .. sj:gsub('"', '\\"'):gsub("\n", "\\n") .. '"'
    elseif type(sj) == "number" then
        return tostring(sj)
    elseif type(sj) == "boolean" then
        return tostring(sj)
    elseif sj == nil then
        return "null"
    end
end

local pz = {
    url = "https://api.deepseek.com/v1",
    key = ""--apikey
}

local mx = {
    {
        mc = "deepseek-chat",
        zdcd = 64000,
        zdsc = 8000,
        ms = "DeepSeek-V3 通用对话模型"
    },
    {
        mc = "deepseek-reasoner",
        zdcd = 64000,
        zdsc = 8000,
        llcd = 32000,
        ms = "DeepSeek-R1 推理模型"
    }
}

local function qq(dp, sj)
    local url = pz.url .. dp
    local tx = {
        ["Cookie"] = "",
        ["User-Agent"] = "Mozilla/5.0",
        ["Accept"] = "*/*",
        ["Accept-Language"] = "en-US,en;q=0.5",
        ["Content-Type"] = "application/json",
        ["Authorization"] = "Bearer " .. pz.key
    }
    local qqt = bj(sj)
    local xy = gg.makeRequest(url, tx, qqt)
    if xy then
        local ks, js = string.find(tostring(xy), 'content":".-"')
        if ks and js then
            local nr = string.sub(tostring(xy), ks+10, js-1)
            return nr
        end
    end
    return xy
end

local function dh(mxmc, xx, zdtk)
    local sj = {
        model = mxmc,
        messages = xx,
        max_tokens = zdtk or 4000
    }
    
    return qq("/chat/completions", sj)
end

local function zc()
    local xz = gg.choice(
        {"DeepSeek-V3 通用对话模型", "DeepSeek-R1 推理模型"},
        nil,
        "请选择模型："
    )
    if not xz then return end
    local mx = mx[xz].mc
    local sr = gg.prompt(
        {"请输入您的问题："},
        {[1]=""}, 
        {[1]="text"}
    )
    if not sr then return end
    gg.toast("正在请求API...")
    local xy = dh(
        mx,
        {{role = "user", content = sr[1]}}
    )
    if xy then
        local xz = gg.choice({"复制回答", "确认"}, nil, xy)
        if xz == 1 then
            gg.copyText(xy)
            gg.toast("已复制AI回答")
        end
    else
        gg.alert("请求失败", "错误")
    end
end
if not gg then
    return
end

zc()