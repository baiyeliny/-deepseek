--[[
作者: 白夜
b站柏枼凛音
AGG对接deepseek
]]

local Tools = import("android.ext.Tools")
local ThreadManager = import("android.ext.ThreadManager")
local layout = import("android.view.ViewGroup$LayoutParams")
local LinearLayout = import("android.widget.LinearLayout")
local MaterialCardView = import("com.google.android.material.card.MaterialCardView")
local Button = import("com.google.android.material.button.MaterialButton")
local LinearProgressIndicator = import("com.google.android.material.progressindicator.LinearProgressIndicator")
local LayoutParams = import("android.widget.LinearLayout$LayoutParams")
local TextView = import("android.widget.TextView")
local ScrollView = import("android.widget.ScrollView")
local EditText = import("android.widget.EditText")

local pz = {
    url = "https://api.deepseek.com/v1",
    key = "" -- apikey
}

local mx = {
    {
        mc = "deepseek-chat",
        zdcd = 64000,
        zdsc = 8000,
        ms = "DeepSeek-V3 通用对话模型"
    },
    {
        mc = "deepseek-reasoner",
        zdcd = 64000,
        zdsc = 8000,
        llcd = 32000,
        ms = "DeepSeek-R1 推理模型"
    }
}

local function bj(sj)
    if type(sj) == "table" then
        local xm = {}
        if #sj > 0 then
            for _, zhi in ipairs(sj) do
                table.insert(xm, bj(zhi))
            end
            return "[" .. table.concat(xm, ",") .. "]"
        else
            for k, v in pairs(sj) do
                table.insert(xm, '"' .. k .. '":' .. bj(v))
            end
            return "{" .. table.concat(xm, ",") .. "}"
        end
    elseif type(sj) == "string" then
        return '"' .. sj:gsub('"', '\\"'):gsub("\n", "\\n") .. '"'
    elseif type(sj) == "number" then
        return tostring(sj)
    elseif type(sj) == "boolean" then
        return tostring(sj)
    elseif sj == nil then
        return "null"
    end
end

local function qq(dp, sj)
    local url = pz.url .. dp
    local tx = {
        ["Cookie"] = "",
        ["User-Agent"] = "Mozilla/5.0",
        ["Accept"] = "*/*",
        ["Accept-Language"] = "en-US,en;q=0.5",
        ["Content-Type"] = "application/json",
        ["Authorization"] = "Bearer " .. pz.key
    }
    
    local qqsj = bj(sj)
    local xy = gg.makeRequest(url, tx, qqsj)
    
    if xy then
        local ks, js = string.find(tostring(xy), 'content":".-"')
        if ks and js then
            local nr = string.sub(tostring(xy), ks+10, js-1)
            return nr:gsub("\\n", "\n"):gsub('\\"', '"')
        end
    end
    return xy
end

local function dh(mxmc, xx, zdtk)
    local sj = {
        model = mxmc,
        messages = xx,
        max_tokens = zdtk or 4000
    }
    return qq("/chat/completions", sj)
end

local function dhcd(mxmc, mxms)
    local sr = gg.prompt(
        {"请输入您的问题："},
        {[1]=""}, 
        {[1]="text"}
    )
    if not sr then return end
    gg.toast("正在请求中...")
    local jg = dh(mxmc, {{role = "user", content = sr[1]}})
    if jg then
        local jgstr = tostring(jg)
        if jgstr == "null" or jgstr == "" then
            gg.alert("未获取到有效回答", "确定")
            return
        end
        local xz = gg.choice({"复制回答", "继续对话", "返回主菜单"}, nil, "AI回答:\n\n" .. jgstr)
        if xz == 1 then
            gg.copyText(jgstr)
            gg.toast("已复制AI回答")
            dhcd(mxmc, mxms)
        elseif xz == 2 then
            dhcd(mxmc, mxms)
        end
    else
        gg.alert("请求失败,请检查网络或API密钥", "错误")
    end
end

local function zcd()
    local cd = {}
    for _, mxsj in ipairs(mx) do
        table.insert(cd, {
            title = mxsj.ms,
            subTitle = "最大长度:" .. mxsj.zdcd .. ", 最大生成:" .. mxsj.zdsc,
            main = function()
                dhcd(mxsj.mc, mxsj.ms)
            end
        })
    end
    local list = gg.viewList(cd)
    window = gg.mainTabs("DeepSeek API", list.getView(), false, window)
end

function zc()
    if not gg then
        return
    end
    while true do
        if gg.isVisible() then
            gg.setVisible(false)
            pcall(zcd)
        end
    end
end

zc()