#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define API_KEY ""//这里填写开放平台的apikey
#define MAX_INPUT 1024
#define MAX_RESPONSE 4096

//模型
typedef enum {
    MODEL_DEEPSEEK_CHAT = 1,
    MODEL_DEEPSEEK_REASONER = 2
} ModelType;

//API
typedef enum {
    API_ORIGINAL = 1,  // 原始API接口
    API_V1 = 2         // V1版本API接口
} ApiType;

//获取API
const char* get_api_url(ApiType api_type) {
    switch(api_type) {
        case API_ORIGINAL:
            return "https://api.deepseek.com/chat/completions";
        case API_V1:
            return "https://api.deepseek.com/v1/chat/completions";
        default:
            return "https://api.deepseek.com/v1/chat/completions";
    }
}

//获取模型
const char* get_model_name(ModelType model) {
    switch(model) {
        case MODEL_DEEPSEEK_CHAT:
            return "deepseek-chat";
        case MODEL_DEEPSEEK_REASONER:
            return "deepseek-reasoner";
        default:
            return "deepseek-chat";
    }
}

ApiType show_api_menu() {
    int choice;
    printf("\n请选择API接口:\n");
    printf("1. 原始接口 (api.deepseek.com/chat/completions)\n");
    printf("2. V1接口  (api.deepseek.com/v1/chat/completions)\n");
    printf("请选择 (1-2): ");
    
    if(scanf("%d", &choice) != 1) {
        choice = 2;
    }
    getchar();
    if(choice != 1 && choice != 2) {
        printf("无效选择，使用默认V1接口\n");
        choice = 2;
    }
    return (ApiType)choice;
}

ModelType show_model_menu() {
    int choice;
    printf("\n请选择模型:\n");
    printf("1. DeepSeek-V3 (通用对话)\n");
    printf("2. DeepSeek-R1 (推理能力增强)\n");
    printf("请选择 (1-2): ");
    
    if(scanf("%d", &choice) != 1) {
        choice = 1;
    }
    getchar();
    if(choice != 1 && choice != 2) {
        printf("无效选择，使用默认模型 DeepSeek-V3\n");
        choice = 1;
    }
    return (ModelType)choice;
}

void escape_json(const char* input, char* output, size_t outsize) {
    size_t j = 0;
    for(size_t i = 0; input[i] && j < outsize - 3; i++) {
        if(input[i] == '"') {
            output[j++] = '\\';
            output[j++] = '"';
        } else if(input[i] == '\\') {
            output[j++] = '\\';
            output[j++] = '\\';
        } else if(input[i] == '\n') {
            output[j++] = '\\';
            output[j++] = 'n';
        } else {
            output[j++] = input[i];
        }
    }
    output[j] = '\0';
}
void extract_and_print_content(const char* response) {
    const char* content_start = strstr(response, "\"content\":\"");
    if(!content_start) {
        printf("AI回答出错，请重试\n");
        return;
    }
    content_start += 11;
    const char* content_end = strchr(content_start, '"');
    if(!content_end) {
        printf("AI回答出错，请重试\n");
        return;
    }
    size_t length = content_end - content_start;
    char* content = (char*)malloc(length + 1);
    if(!content) {
        printf("内存分配失败\n");
        return;
    }
    strncpy(content, content_start, length);
    content[length] = '\0';
    char* src = content;
    char* dst = content;
    while (*src) {
        if (*src == '\\' && *(src + 1)) {
            src++;
            if (*src == 'n') *dst = '\n';
            else if (*src == 'r') *dst = '\r';
            else if (*src == 't') *dst = '\t';
            else *dst = *src;
        } else {
            *dst = *src;
        }
        dst++;
        src++;
    }
    *dst = '\0';
    printf("\nAI: %s\n\n", content);
    free(content);
}

int main() {
    char input[MAX_INPUT];
    char escaped_input[MAX_INPUT * 2];
    char command[MAX_INPUT * 4];
    char response[MAX_RESPONSE];
    ModelType current_model;
    ApiType current_api;
    
    printf("\n============= DeepSeek AI 对话程序 =============\n");
    printf("作者: 白夜\n");
    printf("使用说明:\n");
    printf("1. 直接输入问题即可与AI对话\n");
    printf("2. 输入\"切换模型\"可以切换AI模型\n");
    printf("3. 输入\"切换接口\"可以切换API接口\n");
    printf("4. 输入\"退出\"结束程序\n\n");
    printf("注意事项:\n");
    printf("- 服务器负载高时请耐心等待\n");
    printf("- 如30分钟未收到响应会自动断开\n");
    printf("- 不同场景建议使用不同模型:\n");
    printf("  * 代码/数学: DeepSeek-R1\n");
    printf("  * 通用对话: DeepSeek-V3\n\n");
    //选择API和模型
    current_api = show_api_menu();
    printf("\n当前使用API接口: %s\n", get_api_url(current_api));
    current_model = show_model_menu();
    printf("\n当前使用模型: %s\n", get_model_name(current_model));
    while(1) {
        printf("你: ");
        if(fgets(input, sizeof(input), stdin) == NULL) {
            break;
        }
        input[strcspn(input, "\n")] = 0;
        
        if(strcmp(input, "退出") == 0) {
            printf("\n感谢使用 DeepSeek AI 对话程序！\n");
            break;
        }
        if(strcmp(input, "切换模型") == 0) {
            current_model = show_model_menu();
            printf("\n已切换到模型: %s\n", get_model_name(current_model));
            printf("temperature已自动调整为: %.1f\n\n", 
                   (current_model == MODEL_DEEPSEEK_REASONER) ? 0.0f : 1.0f);
            continue;
        }
        if(strcmp(input, "切换接口") == 0) {
            current_api = show_api_menu();
            printf("\n已切换到API接口: %s\n\n", get_api_url(current_api));
            continue;
        }
        escape_json(input, escaped_input, sizeof(escaped_input));
        float temperature = (current_model == MODEL_DEEPSEEK_REASONER) ? 0.0f : 1.0f;
        snprintf(command, sizeof(command),
            "curl -s '%s' "
            "-H 'Content-Type: application/json' "
            "-H 'Authorization: Bearer %s' "
            "-d '{"
            "\"model\": \"%s\","
            "\"messages\": ["
            "{\"role\": \"system\", \"content\": \"You are a helpful assistant.\"},"
            "{\"role\": \"user\", \"content\": \"%s\"}"
            "],"
            "\"temperature\": %.1f,"
            "\"stream\": false"
            "}'",
            get_api_url(current_api), API_KEY, get_model_name(current_model), 
            escaped_input, temperature);
        FILE* fp = popen(command, "r");
        if(fp == NULL) {
            printf("连接失败，请重试\n");
            continue;
        }
        size_t total = 0;
        size_t bytes;
        while((bytes = fread(response + total, 1, sizeof(response) - total - 1, fp)) > 0) {
            total += bytes;
            if(total >= sizeof(response) - 1) break;
        }
        response[total] = '\0';
        pclose(fp);
        if(total > 0) {
            extract_and_print_content(response);
        } else {
            printf("未收到回答，请重试\n");
        }
    }
    return 0;
}